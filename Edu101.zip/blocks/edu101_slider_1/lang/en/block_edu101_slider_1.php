<?php
$string['configtitle'] = 'Block title';
$string['edu101_slider_1:addinstance'] = 'Add a new [Edu101] Slider style 1 block';
$string['edu101_slider_1:myaddinstance'] = 'Add a new [Edu101] Slider style 1 block to Dashboard';
$string['newcustomsliderblock'] = '[Edu101] Slider style 1';
$string['pluginname'] = '[Edu101] Slider style 1';
$string['slides_number'] = 'Number of slides';
