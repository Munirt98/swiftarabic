<?php
$string['pluginname'] = '[Edu101] Course Rating';
$string['edu101_course_rating'] = '[Edu101] Course Rating';
$string['edu101_course_rating:addinstance'] = 'Add a new [Edu101] Course Rating block';
$string['edu101_course_rating:myaddinstance'] = 'Add a new [Edu101] Course Rating block to the My Moodle page';
