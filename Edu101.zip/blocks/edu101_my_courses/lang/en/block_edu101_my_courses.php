<?php

$string['edu101_my_courses:addinstance'] = 'Add a [Edu101] My Courses block';
$string['edu101_my_courses:myaddinstance'] = 'Add a [Edu101] My Courses block to my moodle';
$string['pluginname'] = '[Edu101] My Courses';
$string['edu101_my_courses'] = '[Edu101] My Courses';
$string['courseid'] = 'Course';
$string['editpagetitle'] = 'Featured courses - editing';
$string['featuredcourse'] = 'Featured course: {$a}';
$string['doadd'] = 'Check to add new featured course';
$string['missingcourseid'] = 'You must select a course.';
$string['sortorder'] = 'Sort order';
$string['missingsortorder'] = 'You must set a sort order.';
$string['deletelink'] = '<a href="{$a}">Delete</a>';
$string['delete_featuredcourse'] = 'Delete featured course';
$string['confirmdelete'] = 'Are you sure you want to delete this course from the list of featured courses?';
$string['config_title'] = 'Title';
