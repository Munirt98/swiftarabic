<?php

$string['edu101_course_grid_5:addinstance'] = 'Add a [Edu101] Featured Courses Masonry 4 block';
$string['edu101_course_grid_5:myaddinstance'] = 'Add a [Edu101] Featured Courses Masonry 4 to my moodle';
$string['pluginname'] = '[Edu101] Featured Courses Masonry 4';
$string['edu101_course_grid_5'] = '[Edu101] Featured Courses Masonry 4';
$string['config_title'] = 'Title';
$string['config_subtitle'] = 'Subtitle';
$string['config_button_text'] = 'Button text';
$string['config_button_link'] = 'Button link';
$string['config_hover_text'] = 'Hover text';
$string['config_hover_accent'] = 'Hover accent';
