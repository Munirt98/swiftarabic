<?php
$string['pluginname'] = '[Edu101] Parallax Subscribe 2';
$string['edu101_parallax_subscribe_2'] = '[Edu101] Parallax Subscribe 2';
$string['edu101_parallax_subscribe_2:addinstance'] = 'Add a [Edu101] Parallax Subscribe block 2';
$string['edu101_parallax_subscribe_2:myaddinstance'] = 'Add a new [Edu101] Parallax Subscribe 2 block to the My Moodle page';
