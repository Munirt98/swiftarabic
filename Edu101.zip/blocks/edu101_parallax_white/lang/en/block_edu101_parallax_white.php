<?php
$string['pluginname'] = '[Edu101] Parallax White';
$string['edu101_parallax_white'] = '[Edu101] Parallax White';
$string['edu101_parallax_white:addinstance'] = 'Add a new Gallery block';
$string['edu101_parallax_white:myaddinstance'] = 'Add a new Gallery block to the My Moodle page';
$string['config_title'] = 'Title';
$string['config_subtitle'] = 'Subtitle';
$string['config_button_text'] = 'Button text';
$string['config_button_link'] = 'Button link';
$string['config_image'] = 'Image';
