<?php
$plugin->component = 'block_edu101_form';
$plugin->version   = 2020110722.10;
$plugin->requires = 2010112400;
