<?php
$string['pluginname'] = '[Edu101] Form';
$string['edu101_form'] = '[Edu101] Form';
$string['edu101_form:addinstance'] = 'Add a new contact form block';
$string['edu101_form:myaddinstance'] = 'Add a new contact form block to the My Moodle page';
$string['config_title'] = 'Select a form: ';
