<?php
$string['pluginname'] = '[Edu101] Gallery Slider';
$string['edu101_gallery_slider'] = '[Edu101] Gallery Slider';
$string['edu101_gallery_slider:addinstance'] = 'Add a new Gallery block';
$string['edu101_gallery_slider:myaddinstance'] = 'Add a new Gallery block to the My Moodle page';
$string['config_title'] = 'Title';
$string['config_image'] = 'Image';
