<?php
$string['pluginname'] = '[Edu101] Hero 7';
$string['edu101_hero_7'] = '[Edu101] Hero 7';
$string['edu101_hero_7:addinstance'] = 'Add a new [Edu101] Hero 7 block';
$string['edu101_hero_7:myaddinstance'] = 'Add a new [Edu101] Hero 7 block to the My Moodle page';
