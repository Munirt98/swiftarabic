<?php

$string['edu101_course_categories_5:addinstance'] = 'Add a new courses block';
$string['edu101_course_categories_5:myaddinstance'] = 'Add a new courses block to Dashboard';
$string['pluginname'] = '[Edu101] Course categories 5';
$string['config_title'] = 'Title';
$string['config_subtitle'] = 'Subtitle';
$string['config_button_link'] = 'Button link';
