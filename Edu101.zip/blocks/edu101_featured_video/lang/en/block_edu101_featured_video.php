<?php

$string['configtitle'] = 'Block title';
$string['edu101_featured_video:addinstance'] = 'Add a new [Edu101] Featured Video block';
$string['edu101_featured_video:myaddinstance'] = 'Add a new [Edu101] Featured Video block to Dashboard';
$string['pluginname'] = '[Edu101] Featured Video';
