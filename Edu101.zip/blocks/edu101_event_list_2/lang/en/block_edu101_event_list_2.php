<?php
$string['edu101_event_list_2:addinstance'] = 'Add a new block';
$string['edu101_event_list_2:myaddinstance'] = 'Add a new block';
$string['pluginname'] = '[Edu101] Event list 2';
