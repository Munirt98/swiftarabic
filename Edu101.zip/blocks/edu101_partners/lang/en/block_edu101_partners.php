<?php
$string['pluginname'] = '[Edu101] Partners';
$string['edu101_partners'] = '[Edu101] Partners';
$string['edu101_partners:addinstance'] = 'Add a new Gallery block';
$string['edu101_partners:myaddinstance'] = 'Add a new Gallery block to the My Moodle page';
$string['config_title'] = 'Title';
$string['config_subtitle'] = 'Subtitle';
$string['config_image'] = 'Image';
