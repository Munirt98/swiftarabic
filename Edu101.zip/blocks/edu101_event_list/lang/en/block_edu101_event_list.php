<?php
$string['edu101_event_list:addinstance'] = 'Add a new block';
$string['edu101_event_list:myaddinstance'] = 'Add a new block';
$string['pluginname'] = '[Edu101] Event list';
