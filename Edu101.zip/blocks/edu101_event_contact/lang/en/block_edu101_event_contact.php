<?php
$string['pluginname'] = '[Edu101] Event Contact';
$string['edu101_event_contact'] = '[Edu101] Event Contact';
$string['edu101_event_contact:addinstance'] = 'Add a new Gallery block';
$string['edu101_event_contact:myaddinstance'] = 'Add a new Gallery block to the My Moodle page';
$string['config_title'] = 'Title';
$string['config_phone'] = 'Phone';
$string['config_email'] = 'Email';
$string['config_website'] = 'Website';
$string['config_map_lat'] = 'Map latitude';
$string['config_map_lng'] = 'Map longitude';
