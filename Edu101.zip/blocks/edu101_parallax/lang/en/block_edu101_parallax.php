<?php
$string['pluginname'] = '[Edu101] Parallax';
$string['edu101_parallax'] = '[Edu101] Parallax';
$string['edu101_parallax:addinstance'] = 'Add a new Gallery block';
$string['edu101_parallax:myaddinstance'] = 'Add a new Gallery block to the My Moodle page';
$string['config_title'] = 'Title';
$string['config_subtitle'] = 'Subtitle';
$string['config_button_text'] = 'Button text';
$string['config_button_link'] = 'Button link';
$string['config_image'] = 'Image';
