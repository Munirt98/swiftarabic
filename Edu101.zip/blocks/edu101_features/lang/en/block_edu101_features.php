<?php
$string['pluginname'] = '[Edu101] Features';
$string['edu101_features'] = '[Edu101] Features';
$string['edu101_features:addinstance'] = 'Add a new Gallery block';
$string['edu101_features:myaddinstance'] = 'Add a new Gallery block to the My Moodle page';
$string['config_image'] = 'Image';
$string['config_feature_1_title'] = 'Title';
$string['config_feature_1_icon'] = 'Icon class';
$string['config_feature_2_title'] = 'Title';
$string['config_feature_2_icon'] = 'Icon class';
$string['config_feature_3_title'] = 'Title';
$string['config_feature_3_icon'] = 'Icon class';
$string['config_feature_4_title'] = 'Title';
$string['config_feature_4_icon'] = 'Icon class';
