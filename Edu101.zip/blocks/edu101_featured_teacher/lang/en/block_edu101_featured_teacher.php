<?php

$string['edu101_featured_teacher:addinstance'] = 'Add a [Edu101] Featured Instructor block';
$string['edu101_featured_teacher:myaddinstance'] = 'Add a [Edu101] Featured Instructor to my moodle';
$string['pluginname'] = '[Edu101] Featured Instructor';
