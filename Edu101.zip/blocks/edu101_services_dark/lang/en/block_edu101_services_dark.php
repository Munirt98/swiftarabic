<?php

$string['configtitle'] = 'Block title';
$string['edu101_services_dark:addinstance'] = 'Add a new [Edu101] Services Dark block';
$string['edu101_services_dark:myaddinstance'] = 'Add a new [Edu101] Services Dark block to Dashboard';
$string['pluginname'] = '[Edu101] Services Dark';
