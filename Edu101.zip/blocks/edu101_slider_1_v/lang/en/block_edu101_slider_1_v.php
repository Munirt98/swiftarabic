<?php
$string['configtitle'] = 'Block title';
$string['edu101_slider_1_v:addinstance'] = 'Add a new [Edu101] Slider style 1 block';
$string['edu101_slider_1_v:myaddinstance'] = 'Add a new [Edu101] Slider style 1 block to Dashboard';
$string['newcustomsliderblock'] = '[Edu101] Slider style 1: Video';
$string['pluginname'] = '[Edu101] Slider style 1: Video';
$string['slides_number'] = 'Number of slides';
