<?php

$string['configtitle'] = 'Block title';
$string['edu101_parallax_features:addinstance'] = 'Add a new [Edu101] Parallax Features block';
$string['edu101_parallax_features:myaddinstance'] = 'Add a new [Edu101] Parallax Features block to Dashboard';
$string['pluginname'] = '[Edu101] Parallax Features';
