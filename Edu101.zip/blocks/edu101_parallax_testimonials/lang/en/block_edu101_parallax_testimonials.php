<?php

$string['configtitle'] = 'Block title';
$string['edu101_parallax_testimonials:addinstance'] = 'Add a new Custom slider block';
$string['edu101_parallax_testimonials:myaddinstance'] = 'Add a new Custom slider block to Dashboard';
$string['leaveblanktohide'] = 'leave blank to hide the title';
$string['newcustomsliderblock'] = '(new Custom slider block)';
$string['pluginname'] = '[Edu101] Parallax Testimonials';

$string['slides_number'] = 'Number of slides';
$string['config_title'] = 'Title';
$string['config_subtitle'] = 'Subtitle';
$string['config_image'] = 'Image';
$string['config_slide_title'] = 'Title';
$string['config_slide_subtitle'] = 'Subtitle';
$string['config_file_slide'] = 'Image';
