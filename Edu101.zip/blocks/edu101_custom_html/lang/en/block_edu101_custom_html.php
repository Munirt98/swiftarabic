<?php
$string['pluginname'] = '[Edu101] Custom HTML';
$string['edu101_custom_html'] = '[Edu101] Custom HTML';
$string['edu101_custom_html:addinstance'] = 'Add a new [Edu101] Custom HTML block';
$string['edu101_custom_html:myaddinstance'] = 'Add a new [Edu101] Custom HTML block to the My Moodle page';
