<?php

$string['configtitle'] = 'Block title';
$string['edu101_event_slider:addinstance'] = 'Add a new Custom slider block';
$string['edu101_event_slider:myaddinstance'] = 'Add a new Custom slider block to Dashboard';
$string['leaveblanktohide'] = 'leave blank to hide the title';
$string['newcustomsliderblock'] = '(new Custom slider block)';
$string['pluginname'] = '[Edu101] Event Slider';

$string['slides_number'] = 'Number of slides';
$string['config_slide_title'] = 'Title';
$string['config_slide_date'] = 'Date';
$string['config_slide_location'] = 'Location';
$string['config_slide_time'] = 'Time';
$string['config_file_slide'] = 'Image';
