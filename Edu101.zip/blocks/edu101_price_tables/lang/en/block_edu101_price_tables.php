<?php

$string['configtitle'] = 'Block title';
$string['edu101_price_tables:addinstance'] = 'Add a new [Edu101] Price Tables block';
$string['edu101_price_tables:myaddinstance'] = 'Add a new [Edu101] Price Tables block to Dashboard';
$string['pluginname'] = '[Edu101] Price Tables';
