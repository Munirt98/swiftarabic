<?php

$string['edu101_more_courses:addinstance'] = 'Add a Edu101 featured courses block';
$string['edu101_more_courses:myaddinstance'] = 'Add a Edu101 featured courses block to my moodle';
$string['pluginname'] = '[Edu101] Related courses';
$string['edu101_more_courses'] = 'Edu101 featured courses';
$string['config_title'] = 'Title';
