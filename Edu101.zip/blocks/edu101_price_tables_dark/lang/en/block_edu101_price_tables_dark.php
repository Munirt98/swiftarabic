<?php

$string['configtitle'] = 'Block title';
$string['edu101_price_tables_dark:addinstance'] = 'Add a new [Edu101] Price Tables Dark block';
$string['edu101_price_tables_dark:myaddinstance'] = 'Add a new [Edu101] Price Tables Dark block to Dashboard';
$string['pluginname'] = '[Edu101] Price Tables Dark';
