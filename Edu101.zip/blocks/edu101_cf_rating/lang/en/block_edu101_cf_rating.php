<?php

$string['edu101_cf_rating:addinstance'] = 'Add a new [Edu101] Course Filter (Rating) block';
$string['edu101_cf_rating:myaddinstance'] = 'Add a new [Edu101] Course Filter (Rating) block to Dashboard';
$string['pluginname'] = '[Edu101] Course Filter (Rating)';
