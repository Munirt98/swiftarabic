<?php
$string['pluginname'] = '[Edu101] About (Text with Image)';
$string['edu101_about_1'] = '[Edu101] About (Text with Image)';
$string['edu101_about_1:addinstance'] = 'Add a new about block with text and an image';
$string['edu101_about_1:myaddinstance'] = 'Add a new about block with text and an image to the My Moodle page';
$string['config_title'] = 'Title';
$string['config_body'] = 'Body';
$string['config_image'] = 'Image';
