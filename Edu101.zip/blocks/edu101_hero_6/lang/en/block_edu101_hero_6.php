<?php
$string['pluginname'] = '[Edu101] Hero 6';
$string['edu101_hero_6'] = '[Edu101] Hero 6';
$string['edu101_hero_6:addinstance'] = 'Add a new [Edu101] Hero 6 block';
$string['edu101_hero_6:myaddinstance'] = 'Add a new [Edu101] Hero 6 block to the My Moodle page';
