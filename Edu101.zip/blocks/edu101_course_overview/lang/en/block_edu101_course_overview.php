<?php
$string['pluginname'] = '[Edu101] Course Overview';
$string['edu101_course_overview'] = '[Edu101] Course Overview';
$string['edu101_course_overview:addinstance'] = 'Add a new Course Overview block';
$string['edu101_course_overview:myaddinstance'] = 'Add a new Course Overview block to the My Moodle page';
$string['config_title'] = 'Title';
$string['config_description'] = 'Description';
