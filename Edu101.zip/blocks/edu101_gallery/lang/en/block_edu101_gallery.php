<?php
$string['pluginname'] = '[Edu101] Gallery';
$string['edu101_gallery'] = '[Edu101] Gallery';
$string['edu101_gallery:addinstance'] = 'Add a new Gallery block';
$string['edu101_gallery:myaddinstance'] = 'Add a new Gallery block to the My Moodle page';
$string['config_title'] = 'Title';
$string['config_image'] = 'Image';
