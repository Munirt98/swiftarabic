<?php
$string['pluginname'] = '[Edu101] Parallax Subscribe';
$string['edu101_parallax_subscribe'] = '[Edu101] Parallax Subscribe';
$string['edu101_parallax_subscribe:addinstance'] = 'Add a [Edu101] Parallax Subscribe block';
$string['edu101_parallax_subscribe:myaddinstance'] = 'Add a new [Edu101] Parallax Subscribe block to the My Moodle page';
