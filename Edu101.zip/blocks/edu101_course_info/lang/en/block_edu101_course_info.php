<?php
$string['pluginname'] = '[Edu101] Course Info';
$string['edu101_course_info'] = '[Edu101] Course Info';
$string['edu101_course_info:addinstance'] = 'Add a new Course Info block';
$string['edu101_course_info:myaddinstance'] = 'Add a new Course Info block to the My Moodle page';
$string['config_title'] = 'Title';
$string['config_body'] = 'Body';
$string['config_image'] = 'Image';
