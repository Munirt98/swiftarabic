<?php
$string['pluginname'] = '[Edu101] My Profile Views';
$string['edu101_myviews'] = '[Edu101] My Profile Views';
$string['edu101_myviews:addinstance'] = 'Add a new My Profile Views block';
$string['edu101_myviews:myaddinstance'] = 'Add a new My Profile Views block to the My Moodle page';
$string['title'] = 'Your Profile Views';
$string['subtitle'] = 'An overview of your profile visits over the last week';
$string['dataset'] = 'Visits';
