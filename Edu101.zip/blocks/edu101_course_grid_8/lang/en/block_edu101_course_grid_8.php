<?php
$string['pluginname'] = '[Edu101] Featured Courses Masonry 6';
