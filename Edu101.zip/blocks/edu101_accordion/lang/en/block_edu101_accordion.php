<?php

$string['configtitle'] = 'Block title';
$string['edu101_accordion:addinstance'] = 'Add a new [Edu101] Accordion block';
$string['edu101_accordion:myaddinstance'] = 'Add a new [Edu101] Accordion to Dashboard';
$string['pluginname'] = '[Edu101] Accordion';
