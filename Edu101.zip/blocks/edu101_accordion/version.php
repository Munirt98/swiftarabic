<?php

defined('MOODLE_INTERNAL') || die();

$plugin->version   = 2021020123.04;
$plugin->requires  = 2018051700;
$plugin->component = 'block_edu101_accordion';
