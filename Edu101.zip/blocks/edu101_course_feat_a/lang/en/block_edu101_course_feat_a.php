<?php
$string['pluginname'] = '[Edu101] Course Features Advanced';
$string['edu101_course_feat_a'] = '[Edu101] Course Features Advanced';
$string['edu101_course_feat_a:addinstance'] = 'Add a new Course Features block';
$string['edu101_course_feat_a:myaddinstance'] = 'Add a new Course Features block to the My Moodle page';
$string['config_title'] = 'Title';
