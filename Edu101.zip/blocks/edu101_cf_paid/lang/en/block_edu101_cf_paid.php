<?php

$string['edu101_cf_paid:addinstance'] = 'Add a new [Edu101] Course Filter (Paid) block';
$string['edu101_cf_paid:myaddinstance'] = 'Add a new [Edu101] Course Filter (Paid) block to Dashboard';
$string['pluginname'] = '[Edu101] Course Filter (Paid)';
