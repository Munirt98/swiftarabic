<?php
$string['edu101_boxes:addinstance'] = 'Add a new [Edu101] Boxes block';
$string['edu101_boxes:myaddinstance'] = 'Add a new [Edu101] Boxes block to Dashboard';
$string['pluginname'] = '[Edu101] Boxes';
