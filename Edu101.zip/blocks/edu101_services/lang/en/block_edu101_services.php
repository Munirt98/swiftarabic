<?php

$string['configtitle'] = 'Block title';
$string['edu101_services:addinstance'] = 'Add a new [Edu101] Services block';
$string['edu101_services:myaddinstance'] = 'Add a new [Edu101] Services block to Dashboard';
$string['pluginname'] = '[Edu101] Services';
