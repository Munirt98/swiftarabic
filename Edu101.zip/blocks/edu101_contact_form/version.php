<?php
$plugin->component = 'block_edu101_contact_form';
$plugin->version   = 2021021017.41;
$plugin->requires = 2010112400;
