<?php

$string['edu101_hero_3:addinstance'] = 'Add a new Edu101 global search block';
$string['edu101_hero_3:myaddinstance'] = 'Add a new Edu101 global search block to Dashboard';
$string['pluginname'] = '[Edu101] Hero 3 (with Search)';
$string['privacy:metadata'] = 'The Edu101 global search block only shows data stored in other locations.';
$string['config_title'] = 'Title';
$string['config_subtitle'] = 'Subtitle';
$string['config_feature_1_title'] = 'Title';
$string['config_feature_1_icon'] = 'Icon class';
$string['config_feature_2_title'] = 'Title';
$string['config_feature_2_icon'] = 'Icon class';
$string['config_feature_3_title'] = 'Title';
$string['config_feature_3_icon'] = 'Icon class';
$string['config_feature_4_title'] = 'Title';
$string['config_feature_4_icon'] = 'Icon class';
