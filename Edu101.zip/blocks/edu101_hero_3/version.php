<?php

defined('MOODLE_INTERNAL') || die;

$plugin->version = 2021031010.51;
$plugin->requires  = 2018051700;
$plugin->component = 'block_edu101_hero_3';
