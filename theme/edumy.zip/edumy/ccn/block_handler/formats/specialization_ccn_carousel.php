<?php
/*
@ccnRef: @block_cocoon/block.php
*/

defined('MOODLE_INTERNAL') || die();

$this->config->ccn_carousel_autoplay = '0';
$this->config->ccn_carousel_autoplay_timeout = '3000';
$this->config->ccn_carousel_autoplay_pause = '0';
$this->config->ccn_carousel_speed = '1000';
$this->config->ccn_carousel_loop = '1';
$this->config->ccn_carousel_lazyload = '0';
$this->config->ccn_carousel_animateout = 'fadeOut';
