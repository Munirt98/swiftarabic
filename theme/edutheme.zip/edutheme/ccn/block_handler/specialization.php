<?php
/*
@ccnRef: @block_Edu101/block.php
*/

defined('MOODLE_INTERNAL') || die();

// if (!($this->config)) {
//   if(!($this->content)){
//     $this->content = new \stdClass();
//   }
//     $this->content->text = '<h5 class="mb30">'.$this->title.'</h5>';
//     return $this->content->text;
// }

// print_object($this);
$ccnBlockType = $this->instance->blockname;

$ccnCollectionFullwidthTop =  array(
  "edu101_about_1",
  "edu101_about_2",
  "edu101_accordion",
  "edu101_action_panels",
  "edu101_blog_recent_slider",
  "edu101_boxes",
  "edu101_event_list",
  "edu101_event_list_2",
  "edu101_faqs",
  "edu101_features",
  "edu101_form",
  "edu101_gallery_video",
  "edu101_parallax",
  "edu101_parallax_apps",
  "edu101_parallax_counters",
  "edu101_parallax_features",
  "edu101_parallax_testimonials",
  "edu101_parallax_subscribe",
  "edu101_parallax_subscribe_2",
  "edu101_partners",
  "edu101_parallax_white",
  "edu101_pills",
  "edu101_price_tables",
  "edu101_price_tables_dark",
  "edu101_services",
  "edu101_services_dark",
  "edu101_simple_counters",
  "edu101_hero_1",
  "edu101_hero_2",
  "edu101_hero_3",
  "edu101_hero_4",
  "edu101_hero_5",
  "edu101_hero_6",
  "edu101_hero_7",
  "edu101_slider_1",
  "edu101_slider_1_v",
  "edu101_slider_2",
  "edu101_slider_3",
  "edu101_slider_4",
  "edu101_slider_5",
  "edu101_slider_6",
  "edu101_slider_7",
  "edu101_slider_8",
  "edu101_steps",
  "edu101_steps_dark",
  "edu101_subscribe",
  "edu101_tablets",
  "edu101_course_categories",
  "edu101_course_categories_2",
  "edu101_course_categories_3",
  "edu101_course_categories_4",
  "edu101_course_categories_5",
  "edu101_course_grid",
  "edu101_course_grid_2",
  "edu101_course_grid_3",
  "edu101_course_grid_4",
  "edu101_course_grid_5",
  "edu101_course_grid_6",
  "edu101_course_grid_7",
  "edu101_course_grid_8",
  "edu101_featuredcourses",
  "edu101_featured_posts",
  "edu101_featured_video",
  "edu101_featured_teacher",
  "edu101_courses_slider",
  "edu101_users_slider",
  "edu101_users_slider_2",
  "edu101_users_slider_2_dark",
  "edu101_users_slider_round",
  "edu101_tstmnls",
  "edu101_tstmnls_2",
  "edu101_tstmnls_3",
  "edu101_tstmnls_4",
  "edu101_tstmnls_5",
  "edu101_tstmnls_6",
);

$ccnCollectionAboveContent =  array(
  "edu101_contact_form",
  "edu101_course_overview",
  "edu101_tabs",
);

$ccnCollectionBelowContent =  array(
  "edu101_course_rating",
  "edu101_more_courses",
  "edu101_course_instructor",
);

$ccnCollection = array_merge($ccnCollectionFullwidthTop, $ccnCollectionAboveContent, $ccnCollectionBelowContent);

if (empty($this->config)) {
  if(in_array($ccnBlockType, $ccnCollectionFullwidthTop)) {
    $this->instance->defaultregion = 'fullwidth-top';
    $this->instance->region = 'fullwidth-top';
    $DB->update_record('block_instances', $this->instance);
  }
  if(in_array($ccnBlockType, $ccnCollectionAboveContent)) {
    $this->instance->defaultregion = 'above-content';
    $this->instance->region = 'above-content';
    $DB->update_record('block_instances', $this->instance);
  }
  if(in_array($ccnBlockType, $ccnCollectionBelowContent)) {
    $this->instance->defaultregion = 'below-content';
    $this->instance->region = 'below-content';
    $DB->update_record('block_instances', $this->instance);
  }
  /* Begin Legacy */
  if(!in_array($ccnBlockType, $ccnCollection)) {
    if(!($this->content)){
       $this->content = new \stdClass();
    }
    $this->content->text = '<h5 class="mb30">'.$this->title.'</h5>';
    return $this->content->text;
  }
  /* End Legacy */
}
